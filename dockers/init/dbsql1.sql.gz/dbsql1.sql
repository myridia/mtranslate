-- MySQL dump 10.16  Distrib 10.1.23-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 10.5.0.2    Database: dbsql1
-- ------------------------------------------------------
-- Server version	12.0.2-MariaDB-ubu2404

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `a_source_target`
--

DROP TABLE IF EXISTS `a_source_target`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `a_source_target` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `source_name` varchar(3) NOT NULL,
  `target_name` varchar(3) NOT NULL,
  `source_id` int(11) NOT NULL,
  `target_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `hash` (`hash`),
  KEY `link` (`source_id`,`target_id`,`source_name`,`target_name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `a_source_target`
--

LOCK TABLES `a_source_target` WRITE;
/*!40000 ALTER TABLE `a_source_target` DISABLE KEYS */;
INSERT INTO `a_source_target` VALUES (1,'c9a2457f','en','th',1,1),(2,'fb01ebcc','en','th',2,2),(3,'d33be262','en','th',3,3),(4,'29b45ab1','en','th',4,4),(5,'4bdc9cef','en','th',5,5),(6,'28293268','en','th',6,6);
/*!40000 ALTER TABLE `a_source_target` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `af`
--

DROP TABLE IF EXISTS `af`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `af` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `af`
--

LOCK TABLES `af` WRITE;
/*!40000 ALTER TABLE `af` DISABLE KEYS */;
/*!40000 ALTER TABLE `af` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `am`
--

DROP TABLE IF EXISTS `am`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `am` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `am`
--

LOCK TABLES `am` WRITE;
/*!40000 ALTER TABLE `am` DISABLE KEYS */;
/*!40000 ALTER TABLE `am` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ar`
--

DROP TABLE IF EXISTS `ar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ar`
--

LOCK TABLES `ar` WRITE;
/*!40000 ALTER TABLE `ar` DISABLE KEYS */;
/*!40000 ALTER TABLE `ar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `az`
--

DROP TABLE IF EXISTS `az`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `az` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `az`
--

LOCK TABLES `az` WRITE;
/*!40000 ALTER TABLE `az` DISABLE KEYS */;
/*!40000 ALTER TABLE `az` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be`
--

DROP TABLE IF EXISTS `be`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be`
--

LOCK TABLES `be` WRITE;
/*!40000 ALTER TABLE `be` DISABLE KEYS */;
/*!40000 ALTER TABLE `be` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bg`
--

DROP TABLE IF EXISTS `bg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bg`
--

LOCK TABLES `bg` WRITE;
/*!40000 ALTER TABLE `bg` DISABLE KEYS */;
/*!40000 ALTER TABLE `bg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bn`
--

DROP TABLE IF EXISTS `bn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bn` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bn`
--

LOCK TABLES `bn` WRITE;
/*!40000 ALTER TABLE `bn` DISABLE KEYS */;
/*!40000 ALTER TABLE `bn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bs`
--

DROP TABLE IF EXISTS `bs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bs`
--

LOCK TABLES `bs` WRITE;
/*!40000 ALTER TABLE `bs` DISABLE KEYS */;
/*!40000 ALTER TABLE `bs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ca`
--

DROP TABLE IF EXISTS `ca`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ca` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ca`
--

LOCK TABLES `ca` WRITE;
/*!40000 ALTER TABLE `ca` DISABLE KEYS */;
/*!40000 ALTER TABLE `ca` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ceb`
--

DROP TABLE IF EXISTS `ceb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ceb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ceb`
--

LOCK TABLES `ceb` WRITE;
/*!40000 ALTER TABLE `ceb` DISABLE KEYS */;
/*!40000 ALTER TABLE `ceb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `co`
--

DROP TABLE IF EXISTS `co`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `co` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `co`
--

LOCK TABLES `co` WRITE;
/*!40000 ALTER TABLE `co` DISABLE KEYS */;
/*!40000 ALTER TABLE `co` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cs`
--

DROP TABLE IF EXISTS `cs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cs`
--

LOCK TABLES `cs` WRITE;
/*!40000 ALTER TABLE `cs` DISABLE KEYS */;
/*!40000 ALTER TABLE `cs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cy`
--

DROP TABLE IF EXISTS `cy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cy`
--

LOCK TABLES `cy` WRITE;
/*!40000 ALTER TABLE `cy` DISABLE KEYS */;
/*!40000 ALTER TABLE `cy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `da`
--

DROP TABLE IF EXISTS `da`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `da` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `da`
--

LOCK TABLES `da` WRITE;
/*!40000 ALTER TABLE `da` DISABLE KEYS */;
/*!40000 ALTER TABLE `da` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `de`
--

DROP TABLE IF EXISTS `de`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `de` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `de`
--

LOCK TABLES `de` WRITE;
/*!40000 ALTER TABLE `de` DISABLE KEYS */;
INSERT INTO `de` VALUES (1,'838e013e','Hallo');
/*!40000 ALTER TABLE `de` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `el`
--

DROP TABLE IF EXISTS `el`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `el` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `el`
--

LOCK TABLES `el` WRITE;
/*!40000 ALTER TABLE `el` DISABLE KEYS */;
/*!40000 ALTER TABLE `el` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `en`
--

DROP TABLE IF EXISTS `en`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `en` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `en`
--

LOCK TABLES `en` WRITE;
/*!40000 ALTER TABLE `en` DISABLE KEYS */;
INSERT INTO `en` VALUES (1,'938b9824','hello'),(2,'0e9cb8a7','world'),(3,'0f1da942','home'),(4,'ea93153d','dad'),(5,'df290235','mother'),(6,'319149a3','child');
/*!40000 ALTER TABLE `en` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eo`
--

DROP TABLE IF EXISTS `eo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eo`
--

LOCK TABLES `eo` WRITE;
/*!40000 ALTER TABLE `eo` DISABLE KEYS */;
/*!40000 ALTER TABLE `eo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `es`
--

DROP TABLE IF EXISTS `es`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `es` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `es`
--

LOCK TABLES `es` WRITE;
/*!40000 ALTER TABLE `es` DISABLE KEYS */;
/*!40000 ALTER TABLE `es` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `et`
--

DROP TABLE IF EXISTS `et`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `et` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `et`
--

LOCK TABLES `et` WRITE;
/*!40000 ALTER TABLE `et` DISABLE KEYS */;
/*!40000 ALTER TABLE `et` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eu`
--

DROP TABLE IF EXISTS `eu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eu`
--

LOCK TABLES `eu` WRITE;
/*!40000 ALTER TABLE `eu` DISABLE KEYS */;
/*!40000 ALTER TABLE `eu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa`
--

DROP TABLE IF EXISTS `fa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa`
--

LOCK TABLES `fa` WRITE;
/*!40000 ALTER TABLE `fa` DISABLE KEYS */;
/*!40000 ALTER TABLE `fa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fi`
--

DROP TABLE IF EXISTS `fi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fi`
--

LOCK TABLES `fi` WRITE;
/*!40000 ALTER TABLE `fi` DISABLE KEYS */;
/*!40000 ALTER TABLE `fi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fr`
--

DROP TABLE IF EXISTS `fr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fr`
--

LOCK TABLES `fr` WRITE;
/*!40000 ALTER TABLE `fr` DISABLE KEYS */;
/*!40000 ALTER TABLE `fr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fy`
--

DROP TABLE IF EXISTS `fy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fy`
--

LOCK TABLES `fy` WRITE;
/*!40000 ALTER TABLE `fy` DISABLE KEYS */;
/*!40000 ALTER TABLE `fy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ga`
--

DROP TABLE IF EXISTS `ga`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ga` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ga`
--

LOCK TABLES `ga` WRITE;
/*!40000 ALTER TABLE `ga` DISABLE KEYS */;
/*!40000 ALTER TABLE `ga` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gd`
--

DROP TABLE IF EXISTS `gd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gd` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gd`
--

LOCK TABLES `gd` WRITE;
/*!40000 ALTER TABLE `gd` DISABLE KEYS */;
/*!40000 ALTER TABLE `gd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gl`
--

DROP TABLE IF EXISTS `gl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gl`
--

LOCK TABLES `gl` WRITE;
/*!40000 ALTER TABLE `gl` DISABLE KEYS */;
/*!40000 ALTER TABLE `gl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gu`
--

DROP TABLE IF EXISTS `gu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gu`
--

LOCK TABLES `gu` WRITE;
/*!40000 ALTER TABLE `gu` DISABLE KEYS */;
/*!40000 ALTER TABLE `gu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ha`
--

DROP TABLE IF EXISTS `ha`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ha` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ha`
--

LOCK TABLES `ha` WRITE;
/*!40000 ALTER TABLE `ha` DISABLE KEYS */;
/*!40000 ALTER TABLE `ha` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `haw`
--

DROP TABLE IF EXISTS `haw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `haw` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `haw`
--

LOCK TABLES `haw` WRITE;
/*!40000 ALTER TABLE `haw` DISABLE KEYS */;
/*!40000 ALTER TABLE `haw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hi`
--

DROP TABLE IF EXISTS `hi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hi`
--

LOCK TABLES `hi` WRITE;
/*!40000 ALTER TABLE `hi` DISABLE KEYS */;
/*!40000 ALTER TABLE `hi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hmn`
--

DROP TABLE IF EXISTS `hmn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hmn` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hmn`
--

LOCK TABLES `hmn` WRITE;
/*!40000 ALTER TABLE `hmn` DISABLE KEYS */;
/*!40000 ALTER TABLE `hmn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hr`
--

DROP TABLE IF EXISTS `hr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hr`
--

LOCK TABLES `hr` WRITE;
/*!40000 ALTER TABLE `hr` DISABLE KEYS */;
/*!40000 ALTER TABLE `hr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ht`
--

DROP TABLE IF EXISTS `ht`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ht` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ht`
--

LOCK TABLES `ht` WRITE;
/*!40000 ALTER TABLE `ht` DISABLE KEYS */;
/*!40000 ALTER TABLE `ht` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hu`
--

DROP TABLE IF EXISTS `hu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hu`
--

LOCK TABLES `hu` WRITE;
/*!40000 ALTER TABLE `hu` DISABLE KEYS */;
/*!40000 ALTER TABLE `hu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hy`
--

DROP TABLE IF EXISTS `hy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hy`
--

LOCK TABLES `hy` WRITE;
/*!40000 ALTER TABLE `hy` DISABLE KEYS */;
/*!40000 ALTER TABLE `hy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ig`
--

DROP TABLE IF EXISTS `ig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ig` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ig`
--

LOCK TABLES `ig` WRITE;
/*!40000 ALTER TABLE `ig` DISABLE KEYS */;
/*!40000 ALTER TABLE `ig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `is`
--

DROP TABLE IF EXISTS `is`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `is` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `is`
--

LOCK TABLES `is` WRITE;
/*!40000 ALTER TABLE `is` DISABLE KEYS */;
/*!40000 ALTER TABLE `is` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `it`
--

DROP TABLE IF EXISTS `it`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `it` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `it`
--

LOCK TABLES `it` WRITE;
/*!40000 ALTER TABLE `it` DISABLE KEYS */;
/*!40000 ALTER TABLE `it` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `iw`
--

DROP TABLE IF EXISTS `iw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `iw` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iw`
--

LOCK TABLES `iw` WRITE;
/*!40000 ALTER TABLE `iw` DISABLE KEYS */;
/*!40000 ALTER TABLE `iw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ja`
--

DROP TABLE IF EXISTS `ja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ja` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ja`
--

LOCK TABLES `ja` WRITE;
/*!40000 ALTER TABLE `ja` DISABLE KEYS */;
/*!40000 ALTER TABLE `ja` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jw`
--

DROP TABLE IF EXISTS `jw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jw` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jw`
--

LOCK TABLES `jw` WRITE;
/*!40000 ALTER TABLE `jw` DISABLE KEYS */;
/*!40000 ALTER TABLE `jw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ka`
--

DROP TABLE IF EXISTS `ka`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ka` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ka`
--

LOCK TABLES `ka` WRITE;
/*!40000 ALTER TABLE `ka` DISABLE KEYS */;
/*!40000 ALTER TABLE `ka` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kk`
--

DROP TABLE IF EXISTS `kk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kk`
--

LOCK TABLES `kk` WRITE;
/*!40000 ALTER TABLE `kk` DISABLE KEYS */;
/*!40000 ALTER TABLE `kk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `km`
--

DROP TABLE IF EXISTS `km`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `km` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `km`
--

LOCK TABLES `km` WRITE;
/*!40000 ALTER TABLE `km` DISABLE KEYS */;
/*!40000 ALTER TABLE `km` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kn`
--

DROP TABLE IF EXISTS `kn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kn` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kn`
--

LOCK TABLES `kn` WRITE;
/*!40000 ALTER TABLE `kn` DISABLE KEYS */;
/*!40000 ALTER TABLE `kn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ko`
--

DROP TABLE IF EXISTS `ko`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ko` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ko`
--

LOCK TABLES `ko` WRITE;
/*!40000 ALTER TABLE `ko` DISABLE KEYS */;
/*!40000 ALTER TABLE `ko` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ku`
--

DROP TABLE IF EXISTS `ku`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ku` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ku`
--

LOCK TABLES `ku` WRITE;
/*!40000 ALTER TABLE `ku` DISABLE KEYS */;
/*!40000 ALTER TABLE `ku` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ky`
--

DROP TABLE IF EXISTS `ky`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ky` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ky`
--

LOCK TABLES `ky` WRITE;
/*!40000 ALTER TABLE `ky` DISABLE KEYS */;
/*!40000 ALTER TABLE `ky` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `la`
--

DROP TABLE IF EXISTS `la`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `la` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `la`
--

LOCK TABLES `la` WRITE;
/*!40000 ALTER TABLE `la` DISABLE KEYS */;
/*!40000 ALTER TABLE `la` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lb`
--

DROP TABLE IF EXISTS `lb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lb`
--

LOCK TABLES `lb` WRITE;
/*!40000 ALTER TABLE `lb` DISABLE KEYS */;
/*!40000 ALTER TABLE `lb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lo`
--

DROP TABLE IF EXISTS `lo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lo`
--

LOCK TABLES `lo` WRITE;
/*!40000 ALTER TABLE `lo` DISABLE KEYS */;
/*!40000 ALTER TABLE `lo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lt`
--

DROP TABLE IF EXISTS `lt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lt`
--

LOCK TABLES `lt` WRITE;
/*!40000 ALTER TABLE `lt` DISABLE KEYS */;
/*!40000 ALTER TABLE `lt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lv`
--

DROP TABLE IF EXISTS `lv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lv`
--

LOCK TABLES `lv` WRITE;
/*!40000 ALTER TABLE `lv` DISABLE KEYS */;
/*!40000 ALTER TABLE `lv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mg`
--

DROP TABLE IF EXISTS `mg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mg`
--

LOCK TABLES `mg` WRITE;
/*!40000 ALTER TABLE `mg` DISABLE KEYS */;
/*!40000 ALTER TABLE `mg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mi`
--

DROP TABLE IF EXISTS `mi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mi`
--

LOCK TABLES `mi` WRITE;
/*!40000 ALTER TABLE `mi` DISABLE KEYS */;
/*!40000 ALTER TABLE `mi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mk`
--

DROP TABLE IF EXISTS `mk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mk`
--

LOCK TABLES `mk` WRITE;
/*!40000 ALTER TABLE `mk` DISABLE KEYS */;
/*!40000 ALTER TABLE `mk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ml`
--

DROP TABLE IF EXISTS `ml`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ml` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ml`
--

LOCK TABLES `ml` WRITE;
/*!40000 ALTER TABLE `ml` DISABLE KEYS */;
/*!40000 ALTER TABLE `ml` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mn`
--

DROP TABLE IF EXISTS `mn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mn` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mn`
--

LOCK TABLES `mn` WRITE;
/*!40000 ALTER TABLE `mn` DISABLE KEYS */;
/*!40000 ALTER TABLE `mn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mr`
--

DROP TABLE IF EXISTS `mr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mr`
--

LOCK TABLES `mr` WRITE;
/*!40000 ALTER TABLE `mr` DISABLE KEYS */;
/*!40000 ALTER TABLE `mr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ms`
--

DROP TABLE IF EXISTS `ms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ms`
--

LOCK TABLES `ms` WRITE;
/*!40000 ALTER TABLE `ms` DISABLE KEYS */;
/*!40000 ALTER TABLE `ms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mt`
--

DROP TABLE IF EXISTS `mt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mt`
--

LOCK TABLES `mt` WRITE;
/*!40000 ALTER TABLE `mt` DISABLE KEYS */;
/*!40000 ALTER TABLE `mt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `my`
--

DROP TABLE IF EXISTS `my`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `my` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `my`
--

LOCK TABLES `my` WRITE;
/*!40000 ALTER TABLE `my` DISABLE KEYS */;
/*!40000 ALTER TABLE `my` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ne`
--

DROP TABLE IF EXISTS `ne`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ne` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ne`
--

LOCK TABLES `ne` WRITE;
/*!40000 ALTER TABLE `ne` DISABLE KEYS */;
/*!40000 ALTER TABLE `ne` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nl`
--

DROP TABLE IF EXISTS `nl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nl`
--

LOCK TABLES `nl` WRITE;
/*!40000 ALTER TABLE `nl` DISABLE KEYS */;
/*!40000 ALTER TABLE `nl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `no`
--

DROP TABLE IF EXISTS `no`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `no` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `no`
--

LOCK TABLES `no` WRITE;
/*!40000 ALTER TABLE `no` DISABLE KEYS */;
/*!40000 ALTER TABLE `no` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ny`
--

DROP TABLE IF EXISTS `ny`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ny` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ny`
--

LOCK TABLES `ny` WRITE;
/*!40000 ALTER TABLE `ny` DISABLE KEYS */;
/*!40000 ALTER TABLE `ny` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `or`
--

DROP TABLE IF EXISTS `or`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `or` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `or`
--

LOCK TABLES `or` WRITE;
/*!40000 ALTER TABLE `or` DISABLE KEYS */;
/*!40000 ALTER TABLE `or` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pa`
--

DROP TABLE IF EXISTS `pa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pa`
--

LOCK TABLES `pa` WRITE;
/*!40000 ALTER TABLE `pa` DISABLE KEYS */;
/*!40000 ALTER TABLE `pa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pl`
--

DROP TABLE IF EXISTS `pl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pl`
--

LOCK TABLES `pl` WRITE;
/*!40000 ALTER TABLE `pl` DISABLE KEYS */;
/*!40000 ALTER TABLE `pl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ps`
--

DROP TABLE IF EXISTS `ps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ps`
--

LOCK TABLES `ps` WRITE;
/*!40000 ALTER TABLE `ps` DISABLE KEYS */;
/*!40000 ALTER TABLE `ps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt`
--

DROP TABLE IF EXISTS `pt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt`
--

LOCK TABLES `pt` WRITE;
/*!40000 ALTER TABLE `pt` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ro`
--

DROP TABLE IF EXISTS `ro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ro` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ro`
--

LOCK TABLES `ro` WRITE;
/*!40000 ALTER TABLE `ro` DISABLE KEYS */;
/*!40000 ALTER TABLE `ro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ru`
--

DROP TABLE IF EXISTS `ru`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ru` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ru`
--

LOCK TABLES `ru` WRITE;
/*!40000 ALTER TABLE `ru` DISABLE KEYS */;
/*!40000 ALTER TABLE `ru` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sd`
--

DROP TABLE IF EXISTS `sd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sd` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sd`
--

LOCK TABLES `sd` WRITE;
/*!40000 ALTER TABLE `sd` DISABLE KEYS */;
/*!40000 ALTER TABLE `sd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `si`
--

DROP TABLE IF EXISTS `si`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `si` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `si`
--

LOCK TABLES `si` WRITE;
/*!40000 ALTER TABLE `si` DISABLE KEYS */;
/*!40000 ALTER TABLE `si` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sk`
--

DROP TABLE IF EXISTS `sk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sk`
--

LOCK TABLES `sk` WRITE;
/*!40000 ALTER TABLE `sk` DISABLE KEYS */;
/*!40000 ALTER TABLE `sk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sl`
--

DROP TABLE IF EXISTS `sl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sl`
--

LOCK TABLES `sl` WRITE;
/*!40000 ALTER TABLE `sl` DISABLE KEYS */;
/*!40000 ALTER TABLE `sl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sm`
--

DROP TABLE IF EXISTS `sm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sm`
--

LOCK TABLES `sm` WRITE;
/*!40000 ALTER TABLE `sm` DISABLE KEYS */;
/*!40000 ALTER TABLE `sm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sn`
--

DROP TABLE IF EXISTS `sn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sn` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sn`
--

LOCK TABLES `sn` WRITE;
/*!40000 ALTER TABLE `sn` DISABLE KEYS */;
/*!40000 ALTER TABLE `sn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `so`
--

DROP TABLE IF EXISTS `so`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `so` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `so`
--

LOCK TABLES `so` WRITE;
/*!40000 ALTER TABLE `so` DISABLE KEYS */;
/*!40000 ALTER TABLE `so` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sq`
--

DROP TABLE IF EXISTS `sq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sq`
--

LOCK TABLES `sq` WRITE;
/*!40000 ALTER TABLE `sq` DISABLE KEYS */;
/*!40000 ALTER TABLE `sq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sr`
--

DROP TABLE IF EXISTS `sr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sr`
--

LOCK TABLES `sr` WRITE;
/*!40000 ALTER TABLE `sr` DISABLE KEYS */;
/*!40000 ALTER TABLE `sr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `st`
--

DROP TABLE IF EXISTS `st`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `st` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `st`
--

LOCK TABLES `st` WRITE;
/*!40000 ALTER TABLE `st` DISABLE KEYS */;
/*!40000 ALTER TABLE `st` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `su`
--

DROP TABLE IF EXISTS `su`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `su` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `su`
--

LOCK TABLES `su` WRITE;
/*!40000 ALTER TABLE `su` DISABLE KEYS */;
/*!40000 ALTER TABLE `su` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sv`
--

DROP TABLE IF EXISTS `sv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sv`
--

LOCK TABLES `sv` WRITE;
/*!40000 ALTER TABLE `sv` DISABLE KEYS */;
/*!40000 ALTER TABLE `sv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sw`
--

DROP TABLE IF EXISTS `sw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sw` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sw`
--

LOCK TABLES `sw` WRITE;
/*!40000 ALTER TABLE `sw` DISABLE KEYS */;
/*!40000 ALTER TABLE `sw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ta`
--

DROP TABLE IF EXISTS `ta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ta`
--

LOCK TABLES `ta` WRITE;
/*!40000 ALTER TABLE `ta` DISABLE KEYS */;
/*!40000 ALTER TABLE `ta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `te`
--

DROP TABLE IF EXISTS `te`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `te` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `te`
--

LOCK TABLES `te` WRITE;
/*!40000 ALTER TABLE `te` DISABLE KEYS */;
/*!40000 ALTER TABLE `te` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tg`
--

DROP TABLE IF EXISTS `tg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tg`
--

LOCK TABLES `tg` WRITE;
/*!40000 ALTER TABLE `tg` DISABLE KEYS */;
/*!40000 ALTER TABLE `tg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `th`
--

DROP TABLE IF EXISTS `th`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `th` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `th`
--

LOCK TABLES `th` WRITE;
/*!40000 ALTER TABLE `th` DISABLE KEYS */;
INSERT INTO `th` VALUES (1,'e226198a','สวัสดี'),(2,'fc5b9f97','โลก'),(3,'fcd8e912','บ้าน'),(4,'20c32aaa','พ่อ'),(5,'a9c5d538','แม่'),(6,'b271e39c','เด็ก');
/*!40000 ALTER TABLE `th` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tl`
--

DROP TABLE IF EXISTS `tl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tl`
--

LOCK TABLES `tl` WRITE;
/*!40000 ALTER TABLE `tl` DISABLE KEYS */;
/*!40000 ALTER TABLE `tl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tr`
--

DROP TABLE IF EXISTS `tr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tr`
--

LOCK TABLES `tr` WRITE;
/*!40000 ALTER TABLE `tr` DISABLE KEYS */;
/*!40000 ALTER TABLE `tr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uk`
--

DROP TABLE IF EXISTS `uk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uk`
--

LOCK TABLES `uk` WRITE;
/*!40000 ALTER TABLE `uk` DISABLE KEYS */;
/*!40000 ALTER TABLE `uk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ur`
--

DROP TABLE IF EXISTS `ur`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ur`
--

LOCK TABLES `ur` WRITE;
/*!40000 ALTER TABLE `ur` DISABLE KEYS */;
/*!40000 ALTER TABLE `ur` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uz`
--

DROP TABLE IF EXISTS `uz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uz`
--

LOCK TABLES `uz` WRITE;
/*!40000 ALTER TABLE `uz` DISABLE KEYS */;
/*!40000 ALTER TABLE `uz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vi`
--

DROP TABLE IF EXISTS `vi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vi`
--

LOCK TABLES `vi` WRITE;
/*!40000 ALTER TABLE `vi` DISABLE KEYS */;
/*!40000 ALTER TABLE `vi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xh`
--

DROP TABLE IF EXISTS `xh`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xh` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xh`
--

LOCK TABLES `xh` WRITE;
/*!40000 ALTER TABLE `xh` DISABLE KEYS */;
/*!40000 ALTER TABLE `xh` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `yi`
--

DROP TABLE IF EXISTS `yi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yi`
--

LOCK TABLES `yi` WRITE;
/*!40000 ALTER TABLE `yi` DISABLE KEYS */;
/*!40000 ALTER TABLE `yi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `yo`
--

DROP TABLE IF EXISTS `yo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yo`
--

LOCK TABLES `yo` WRITE;
/*!40000 ALTER TABLE `yo` DISABLE KEYS */;
/*!40000 ALTER TABLE `yo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zh-CN`
--

DROP TABLE IF EXISTS `zh-CN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zh-CN` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zh-CN`
--

LOCK TABLES `zh-CN` WRITE;
/*!40000 ALTER TABLE `zh-CN` DISABLE KEYS */;
/*!40000 ALTER TABLE `zh-CN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zh-TW`
--

DROP TABLE IF EXISTS `zh-TW`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zh-TW` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zh-TW`
--

LOCK TABLES `zh-TW` WRITE;
/*!40000 ALTER TABLE `zh-TW` DISABLE KEYS */;
/*!40000 ALTER TABLE `zh-TW` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zu`
--

DROP TABLE IF EXISTS `zu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zu`
--

LOCK TABLES `zu` WRITE;
/*!40000 ALTER TABLE `zu` DISABLE KEYS */;
/*!40000 ALTER TABLE `zu` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-28 11:53:39
