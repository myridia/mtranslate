-- MySQL dump 10.16  Distrib 10.1.23-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 10.5.0.2    Database: dbsql1
-- ------------------------------------------------------
-- Server version	12.0.2-MariaDB-ubu2404

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `a_source_target`
--

DROP TABLE IF EXISTS `a_source_target`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `a_source_target` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `source_name` varchar(3) NOT NULL,
  `target_name` varchar(3) NOT NULL,
  `source_id` int(11) NOT NULL,
  `target_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `hash` (`hash`),
  KEY `link` (`source_id`,`target_id`,`source_name`,`target_name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `a_source_target`
--

LOCK TABLES `a_source_target` WRITE;
/*!40000 ALTER TABLE `a_source_target` DISABLE KEYS */;
INSERT INTO `a_source_target` VALUES (1,'c9a2457f','en','th',1,1),(2,'fb01ebcc','en','th',2,2),(3,'d33be262','en','th',3,3),(4,'29b45ab1','en','th',4,4),(5,'4bdc9cef','en','th',5,5),(6,'28293268','en','th',6,6);
/*!40000 ALTER TABLE `a_source_target` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `en`
--

DROP TABLE IF EXISTS `en`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `en` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `en`
--

LOCK TABLES `en` WRITE;
/*!40000 ALTER TABLE `en` DISABLE KEYS */;
INSERT INTO `en` VALUES (1,'938b9824','hello'),(2,'0e9cb8a7','world'),(3,'0f1da942','home'),(4,'ea93153d','dad'),(5,'df290235','mother'),(6,'319149a3','child');
/*!40000 ALTER TABLE `en` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `th`
--

DROP TABLE IF EXISTS `th`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `th` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(16) NOT NULL DEFAULT '',
  `text` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash` (`hash`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `th`
--

LOCK TABLES `th` WRITE;
/*!40000 ALTER TABLE `th` DISABLE KEYS */;
INSERT INTO `th` VALUES (1,'e226198a','สวัสดี'),(2,'fc5b9f97','โลก'),(3,'fcd8e912','บ้าน'),(4,'20c32aaa','พ่อ'),(5,'a9c5d538','แม่'),(6,'b271e39c','เด็ก');
/*!40000 ALTER TABLE `th` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-27  2:04:43
